export interface TextEdit {
    editStart: number;
    deletedText: string;
    insertedText: string;
}
//# sourceMappingURL=textEdit.d.ts.map